document.addEventListener("DOMContentLoaded", function () {
    function initHorizontalScroll(slideshowId, images) {
        const slideshow = document.getElementById(slideshowId);
        if (!slideshow) {
            console.error(`Element with ID '${slideshowId}' not found.`);
            return;
        }

        slideshow.style.overflow = "hidden";
        slideshow.style.width = "100%";
        slideshow.style.position = "relative";
        slideshow.style.height = "auto";

        const container = document.createElement("div");
        container.style.display = "flex";
        container.style.gap = "20px";
        container.style.width = "max-content";
        container.classList.add("scrolling-container");
        slideshow.appendChild(container);

        // Duplicate images for seamless scrolling
        const imageSet = [...images, ...images];
        imageSet.forEach(src => {
            let img = document.createElement("img");
            img.src = src;
            img.style.width = "300px";
            img.style.height = "auto";
            img.style.objectFit = "cover";
            img.onerror = () => console.error(`Image not found: ${src}`);
            container.appendChild(img);
        });

        // Auto-scrolling effect
        let scrollAmount = 0;
        function scrollImages() {
            scrollAmount += 1;
            if (scrollAmount >= container.scrollWidth / 2) {
                scrollAmount = 0;
            }
            container.style.transform = `translateX(-${scrollAmount}px)`;
            requestAnimationFrame(scrollImages);
        }
        requestAnimationFrame(scrollImages);
    }

    // Ensure the modal is hidden on page load
    const modal = document.getElementById("quote-modal");
    if (modal) {
        modal.style.display = "none";
    }

    // Fix "Get Quote" button functionality
    document.querySelectorAll(".get-quote-btn").forEach(button => {
        button.addEventListener("click", function () {
            if (modal) modal.style.display = "flex";
        });
    });

    // Fix "X" close button functionality
    const closeBtnOutside = document.querySelector(".close-outside");
    if (closeBtnOutside) {
        closeBtnOutside.addEventListener("click", function () {
            if (modal) modal.style.display = "none";
        });
    }

    // Close modal when clicking outside the modal content
    window.addEventListener("click", function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });

    // Initialize slideshows for all sections
    initHorizontalScroll("logo-slideshow", [
        "assets/portfolio/logo1.jpg", "assets/portfolio/logo2.jpg", "assets/portfolio/logo3.jpg",
        "assets/portfolio/logo4.jpg", "assets/portfolio/logo5.jpg"
    ]);

    initHorizontalScroll("customer-slideshow", [
        "assets/portfolio/customer1.jpg", "assets/portfolio/customer2.jpg", "assets/portfolio/customer3.jpg",
        "assets/portfolio/customer4.jpg", "assets/portfolio/customer5.jpg"
    ]);

    // Fix missing image sections
    initHorizontalScroll("poster-slideshow", [
        "assets/portfolio/poster1.jpg", "assets/portfolio/poster2.jpg", "assets/portfolio/poster3.jpg",
        "assets/portfolio/poster4.jpg", "assets/portfolio/poster5.jpg"
    ]);

    initHorizontalScroll("album-slideshow", [
        "assets/portfolio/album1.jpg", "assets/portfolio/album2.jpg", "assets/portfolio/album3.jpg",
        "assets/portfolio/album4.jpg", "assets/portfolio/album5.jpg"
    ]);

    initHorizontalScroll("print-slideshow", [
        "assets/portfolio/print1.jpg", "assets/portfolio/print2.jpg", "assets/portfolio/print3.jpg",
        "assets/portfolio/print4.jpg", "assets/portfolio/print5.jpg"
    ]);

    initHorizontalScroll("ads-slideshow", [
        "assets/portfolio/ads1.jpg", "assets/portfolio/ads2.jpg", "assets/portfolio/ads3.jpg",
        "assets/portfolio/ads4.jpg", "assets/portfolio/ads5.jpg"
    ]);
});
